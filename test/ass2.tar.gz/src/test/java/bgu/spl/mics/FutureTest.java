package bgu.spl.mics;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class FutureTest {
    @BeforeEach
    public void setUp(){

    }

    @Test
    public void test(){
        // change this test and add
        fail("Not a good test");
    }
}
